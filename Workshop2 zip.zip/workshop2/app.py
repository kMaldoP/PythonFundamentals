from banking_pkg import account


def atm_menu(name): # Program start menu
    print("")
    print("          === Automated Teller Machine ===          ")
    print("User: " + name)
    print("------------------------------------------")
    print("| 1.    Balance     | 2.    Deposit      |")
    print("------------------------------------------")
    print("------------------------------------------")
    print("| 3.    Withdraw    | 4.    Logout       |")
    print("------------------------------------------")


print("          === Automated Teller Machine ===          ")

user = account.validate_length()
pin = account.validate_pin()
balance = float(0)

print(f"{user} has been registered with a starting balance of ${balance}")

while True: #validating user login and password
    print(" Login ")
    name_to_validate = input("Enter Name: ")
    pin_to_validate = input("Enter Pin: ")
    if name_to_validate == user and pin_to_validate == pin:
        print("Login sucessful!")
        break
    else:
        print("INVALID CREDENTIALS")

while True: #atm menu after sucessful user authentication
    atm_menu(user)
    option = input("Choose an option:")

    if option == "1":
        account.show_balance(balance)
    elif option == "2":
        balance = account.deposit(balance)
        account.show_balance(balance)
    elif option == "3":
        balance = account.withdraw(balance)
        account.show_balance(balance)
    elif option == "4":
        account.logout(user)
        break
    else:
        print("Invalid Option")
        continue
